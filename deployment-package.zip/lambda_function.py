def lambda_handler(event, context):
    """_summary_

    Args:
        event (_type_): _description_
        context (_type_): _description_

    Returns:
        _type_: _description_
    """
    return {
        'statusCode': 200,
        'body': 'Hello from Lambda!'
    }
